import { MdPayment } from 'react-icons/md';
import { GoFlame } from 'react-icons/go';
export const Payment: React.FC<React.SVGAttributes<{}>> = (props) => (
  <MdPayment className="h-6 w-6 mr-3" color="#808080" />
);
