import { FaBox } from 'react-icons/fa';

export const InventoryIcons = (props) => (
  <FaBox className="h-5 w-5 me-4" color='gray' />
);
