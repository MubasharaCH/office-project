import { SlDiamond } from "react-icons/sl";

export const BrandIcons: React.FC<React.SVGAttributes<{}>> = (props) => (
    <SlDiamond className="h-5 w-5 me-4" color='gray' />
  );
  