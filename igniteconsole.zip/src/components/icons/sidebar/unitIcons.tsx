import { TbScale } from "react-icons/tb";

export const UnitIcons: React.FC<React.SVGAttributes<{}>> = (props) => (
    <TbScale className="h-5 w-5 me-4" color='gray' />
  );
  