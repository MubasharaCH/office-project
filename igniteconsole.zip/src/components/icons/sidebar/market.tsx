import { CiShop } from 'react-icons/ci';
export const Market: React.FC<React.SVGAttributes<{}>> = (props) => (
    <CiShop className='h-6 w-6 mr-3' color='#808080'/>
  );
  