import { FaSync } from 'react-icons/fa';

export const transferIcons = (props) => (
  <FaSync className="h-5 w-5 me-4" color='gray' />
);
