import { ImTable2 } from 'react-icons/im';

export const TableIcon = (props) => (
  <ImTable2 className="h-5 w-5 me-4" color="gray" />
);
