import { AiOutlineBarChart } from 'react-icons/ai';
import { FaAdjust } from 'react-icons/fa';

export const sizeChart = (props) => (
  <AiOutlineBarChart className="h-5 w-5 me-4" color="gray" />
);
