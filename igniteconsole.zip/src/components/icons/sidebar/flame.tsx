import { FaShippingFast } from 'react-icons/fa';
export const Flame: React.FC<React.SVGAttributes<{}>> = (props) => (
  <FaShippingFast className="h-6 w-6 mr-3" color="#808080" />
);
