import { MdOutlinePointOfSale } from 'react-icons/md';

export const purchase = (props) => (
  <MdOutlinePointOfSale className="h-5 w-5 me-4" color="gray" />
);
