import { FaAdjust } from 'react-icons/fa';

export const AdjustIcons = (props) => (
  <FaAdjust className="h-5 w-5 me-4" color='gray' />
);
