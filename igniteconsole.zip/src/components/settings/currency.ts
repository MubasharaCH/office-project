

export const CURRENCY: any = [
  {
    key: '91',
    name: 'Rupees',
  },
  {
    key: '101',
    name: 'Riyals',
  },
  {
    key: '102',
    name: 'Dinars',
  },
  {
    key: '103',
    name: 'Rupees',
  },
  {
    key: '104',
    name: 'Dollars',
  },
  {
    key: '105',
    name: 'Euro',
  },
  {
    key: '106',
    name: 'Dollars',
  },
  {
    key: '107',
    name: 'Shillings',
  },
  {
    key: '108',
    name: 'Rand',
  },
  {
    key: '109',
    name: 'Won',
  },
  {
    key: '110',
    name: 'Euro',
  },
  {
    key: '111',
    name: 'Rupees',
  },
  {
    key: '112',
    name: 'Kronor',
  },
  {
    key: '113',
    name: 'Francs',
  },
  {
    key: '114',
    name: 'Dollars',
  },
  {
    key: '115',
    name: 'Pounds',
  },
  {
    key: '116',
    name: 'New Dollars',
  },
  {
    key: '117',
    name: 'Baht',
  },
  {
    key: '118',
    name: 'Dollars',
  },
  {
    key: '119',
    name: 'Lira',
  },
  {
    key: '120',
    name: 'Liras',
  },
  {
    key: '121',
    name: 'Dollars',
  },
  {
    key: '122',
    name: 'Hryvnia',
  },
  {
    key: '123',
    name: 'Pounds',
  },
  {
    key: '124',
    name: 'Dollars',
  },
  {
    key: '125',
    name: 'Pesos',
  },
  {
    key: '126',
    name: 'Sums',
  },
  {
    key: '127',
    name: 'Euro',
  },
  {
    key: '128',
    name: 'Bolivares Fuertes',
  },
  {
    key: '129',
    name: 'Dong',
  },
  {
    key: '130',
    name: 'Rials',
  },
  {
    key: '131',
    name: 'Zimbabwe Dollars',
  },
  {
    key: '132',
    name: 'Iraqi dinar',
  },
  {
    key: '133',
    name: 'Kenyan shilling',
  },
  {
    key: '134',
    name: 'Taka',
  },
  {
    key: '135',
    name: 'Algerian dinar',
  },
  {
    key: '136',
    name: 'United Arab Emirates dirham',
  },
  {
    key: '137',
    name: 'Uganda shillings',
  },
  {
    key: '138',
    name: 'Tanzanian shilling',
  },
  {
    key: '139',
    name: 'Kwanza',
  },
  {
    key: '140',
    name: 'Kuwaiti dinar',
  },
  {
    key: '141',
    name: 'Bahraini dinar',
  },
];
