export const unitDrop = [
    {
      value: 'product',
      label: 'Product',
    },
    {
      value: 'category',
      label: 'Category',
    },
  ];

  export const dataDrop = [
    {
      value: 'text',
      label: 'text',
    },
    {
      value: 'integer',
      label: 'integer',
    },
    {
      value: 'boolean',
      label: 'boolean',
    },

    {
      value: 'dropdown',
      label: 'dropdown',
    },
  ];

  